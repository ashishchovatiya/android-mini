[![Open Source Love](https://badges.frapsoft.com/os/v1/open-source.png?v=103)]()
[![Failed](https://ci.appveyor.com/api/projects/status/github/gruntjs/grunt?branch=master&svg=true)]()
# Women-Safety-App
An android app which can INSTANTLY alert the Guardians( along with user location ) whenever the user is in an emergency situation. It can be triggered just by shaking the android device in which the app is installed.
